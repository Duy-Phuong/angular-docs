import { AuthValidators } from './auth-validators';

describe('AuthValidators', () => {
  it('should create an instance', () => {
    expect(new AuthValidators()).toBeTruthy();
  });
});
