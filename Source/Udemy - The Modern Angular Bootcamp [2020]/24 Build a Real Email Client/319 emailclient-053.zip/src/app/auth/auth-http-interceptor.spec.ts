import { AuthHttpInterceptor } from './auth-http-interceptor';

describe('AuthHttpInterceptor', () => {
  it('should create an instance', () => {
    expect(new AuthHttpInterceptor()).toBeTruthy();
  });
});
