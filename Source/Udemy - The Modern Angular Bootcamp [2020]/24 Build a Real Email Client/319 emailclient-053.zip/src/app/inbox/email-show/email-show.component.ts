import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-show',
  templateUrl: './email-show.component.html',
  styleUrls: ['./email-show.component.css']
})
export class EmailShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
