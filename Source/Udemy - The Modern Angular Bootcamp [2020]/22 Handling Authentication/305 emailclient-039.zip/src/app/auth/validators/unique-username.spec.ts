import { UniqueUsername } from './unique-username';

describe('UniqueUsername', () => {
  it('should create an instance', () => {
    expect(new UniqueUsername()).toBeTruthy();
  });
});
