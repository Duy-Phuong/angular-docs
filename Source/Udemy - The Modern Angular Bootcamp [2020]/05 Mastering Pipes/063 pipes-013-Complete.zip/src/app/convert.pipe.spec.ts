import { ConvertPipe } from './convert.pipe';

describe('ConvertPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertPipe();
    expect(pipe).toBeTruthy();
  });
});
