import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-na-article-list',
  templateUrl: './na-article-list.component.html',
  styleUrls: ['./na-article-list.component.css']
})
export class NaArticleListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
